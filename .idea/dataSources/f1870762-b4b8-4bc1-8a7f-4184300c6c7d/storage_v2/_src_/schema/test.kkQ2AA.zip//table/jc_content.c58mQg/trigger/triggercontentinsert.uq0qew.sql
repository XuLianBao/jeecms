create trigger triggerContentInsert
  after INSERT
  on jc_content
  for each row
  update jc_site_attr set attr_value=attr_value+1 where attr_name="contentTotal" and site_id=new.site_id;

