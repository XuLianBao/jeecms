create trigger triggerContentDelete
  after DELETE
  on jc_content
  for each row
  update jc_site_attr set attr_value=attr_value-1 where attr_name="contentTotal" and site_id=old.site_id;

