create trigger triggerCommentInsert
  after INSERT
  on jc_comment
  for each row
  update jc_site_attr set attr_value=attr_value+1 where attr_name="commentTotal" and site_id=new.site_id;

