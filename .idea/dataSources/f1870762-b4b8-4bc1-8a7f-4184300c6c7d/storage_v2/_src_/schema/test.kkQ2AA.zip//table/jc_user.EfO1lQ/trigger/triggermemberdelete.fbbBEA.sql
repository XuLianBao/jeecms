create trigger triggerMemberDelete
  after DELETE
  on jc_user
  for each row
  update jc_site_attr set attr_value=attr_value-1 where attr_name="memberTotal" and site_id=1 and old.is_admin=0;

